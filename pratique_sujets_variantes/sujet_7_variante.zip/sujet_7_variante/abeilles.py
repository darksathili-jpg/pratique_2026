import random


class Abeille:
    def __init__(self, role, age, energie):
        self.age = age
        self.esperance_de_vie = random.randint(30, 60)
        self.role = role           # "ouvriere" ou "faux_bourdon"
        self.energie = energie     # niveau d'énergie accumulé (en unités de nectar)

    def butiner(self, nb_fleurs, nb_abeilles):
        """
        ### À documenter — Question 3 ###
        """
        if nb_abeilles == 0:
            return nb_fleurs

        fleurs_par_abeille = nb_fleurs / nb_abeilles

        if fleurs_par_abeille > 15:
            recolte = random.randint(8, 15)
        elif fleurs_par_abeille > 7:
            recolte = random.randint(4, 10)
        else:
            recolte = random.randint(1, 5)

        recolte = min(recolte, nb_fleurs)

        if recolte >= 7:
            self.energie += 1
        else:
            self.energie = max(0, self.energie - 1)

        return nb_fleurs - recolte

    def eclosion(self):
        """
        Une ouvrière avec un niveau d'énergie >= 2 engendre exactement
        deux nouvelles abeilles : un faux-bourdon et une ouvrière.
        """
        naissance = []
        if self.role == "ouvriere" and self.energie >= 2:
            naissance.append(Abeille("faux_bourdon", 0, 0))
            naissance.append(Abeille("ouvriere", 0, 0))
            self.energie = 0

        return naissance

    def a_survecu(self):
        """
        Met à jour l'âge de l'abeille et indique si elle est encore en vie.
        """
        self.age = self.age + 1
        return self.age < self.esperance_de_vie

    def __repr__(self):
        return (f"Abeille {self.role}, "
                f"âge : {self.age}/{self.esperance_de_vie}, "
                f"énergie : {self.energie}")


def cycle_journalier(ruche, nb_fleurs):
    """
    Simule une journée dans l'écosystème de la ruche :
    - butinage des abeilles
    - éclosion de nouvelles abeilles
    - vieillissement et mortalité
    - repousse naturelle des fleurs

    ruche est une liste d'instances de la classe Abeille.
    nb_fleurs est un entier indiquant le nombre de fleurs disponibles.

    Cette fonction renvoie un couple (ruche_suivante, nouveau_nb_fleurs)
    indiquant la nouvelle ruche à la fin de la journée et le nombre de fleurs.
    """
    ruche_suivante = []
    nouveau_nes = []
    nb_abeilles = len(ruche)

    for abeille in ruche:
        nb_fleurs = abeille.butiner(nb_fleurs, nb_abeilles)

        if abeille.a_survecu():
            ruche_suivante.append(abeille)

        nouveau_nes += abeille.eclosion()

    # Repousse naturelle des fleurs (augmentation de 15 % par jour)
    nb_fleurs = int(nb_fleurs * 1.15)

    # Ajout des nouveau-nées en fin de journée
    ruche_suivante += nouveau_nes

    return ruche_suivante, nb_fleurs


##############################################################################
# Écrire ci-dessous le code pour les questions de l'énoncé                  #
##############################################################################
