# =============================================================================
#  NSI Terminale — BAC 2026 — Variante du Sujet n°22 — Partie pratique
#  Thème : Trame binaire & décodage ASCII
#  Lycée Antoine Watteau — Terminale NSI
# =============================================================================
#
#  CONTEXTE
#  --------
#  Un réseau de capteurs IoT (Internet of Things) transmet des identifiants
#  de stations sous forme de trames binaires.
#  Chaque trame est une liste de tuples ; chaque tuple représente un octet
#  (8 bits) codant un caractère ASCII.
#
#  PIPELINE DE DÉCODAGE :
#
#    trame (liste de tuples binaires)
#      → octet2dec  sur chaque tuple  → liste d'entiers décimaux
#      → dec2msg    sur la liste      → chaîne de caractères (identifiant station)
#
# =============================================================================


# -----------------------------------------------------------------------------
#  DONNÉES FOURNIES — ne pas modifier
# -----------------------------------------------------------------------------

# Figure 1 — Trame binaire de l'exemple (7 octets = 7 tuples de 8 bits)
# Elle code l'identifiant de station : "NSI-BAC"

figure1 = [
    (0, 1, 0, 0, 1, 1, 1, 0),  # octet 0 → 'N'  (78)
    (0, 1, 0, 1, 0, 0, 1, 1),  # octet 1 → 'S'  (83)
    (0, 1, 0, 0, 1, 0, 0, 1),  # octet 2 → 'I'  (73)
    (0, 0, 1, 0, 1, 1, 0, 1),  # octet 3 → '-'  (45)
    (0, 1, 0, 0, 0, 0, 1, 0),  # octet 4 → 'B'  (66)
    (0, 1, 0, 0, 0, 0, 0, 1),  # octet 5 → 'A'  (65)
    (0, 1, 0, 0, 0, 0, 1, 1),  # octet 6 → 'C'  (67)
]

# Table ASCII fournie : associe un entier décimal à son caractère ASCII
# (couvre les caractères imprimables : codes 32 à 126)
dict_ascii = {i: chr(i) for i in range(32, 127)}


# =============================================================================
#  QUESTION 1 — Fonction octet2dec
# =============================================================================
#
#  Écrire une fonction octet2dec(tuple_bits) qui prend en paramètre un tuple
#  représentant un octet en binaire (8 bits) et qui renvoie l'entier
#  naturel en base 10 correspondant.
#
#  On utilisera la méthode de Horner :
#    Pour chaque bit lu de gauche à droite :  r = r * 2 + bit
#
#  Exemples attendus :
#    octet2dec((0, 1, 0, 0, 1, 1, 1, 0))  →  78   (caractère 'N')
#    octet2dec((0, 0, 1, 0, 1, 1, 0, 1))  →  45   (caractère '-')
#    octet2dec((0, 1, 0, 0, 0, 0, 0, 1))  →  65   (caractère 'A')
#
#  Squelette :
#    def octet2dec(tuple_bits):
#        r = 0
#        for bit in tuple_bits:
#            r = ...   # une seule ligne : formule de Horner
#        return r
#
# -----------------------------------------------------------------------------

def octet2dec(tuple_bits):
    # À compléter
    pass


# --- Tests Question 1 --------------------------------------------------------
print("=" * 50)
print("QUESTION 1 — octet2dec")
print("=" * 50)
print(octet2dec((0, 1, 0, 0, 1, 1, 1, 0)), "  attendu : 78")
print(octet2dec((0, 0, 1, 0, 1, 1, 0, 1)), "  attendu : 45")
print(octet2dec((0, 1, 0, 0, 0, 0, 0, 1)), "  attendu : 65")
print(octet2dec((0, 1, 0, 1, 0, 0, 1, 1)), "  attendu : 83")
print(octet2dec((0, 1, 0, 0, 0, 0, 1, 1)), "  attendu : 67")
print()


# =============================================================================
#  QUESTION 2 — Fonction trame2dec
# =============================================================================
#
#  En utilisant la fonction octet2dec de la question précédente,
#  écrire une fonction trame2dec(trame) qui prend en paramètre une trame
#  (liste de tuples binaires) et renvoie la liste des entiers correspondants.
#
#  Exemple attendu :
#    trame2dec(figure1)  →  [78, 83, 73, 45, 66, 65, 67]
#
#  Deux styles d'écriture sont acceptés :
#    - Boucle for classique avec append
#    - Compréhension de liste (recommandée au BAC)
#
# -----------------------------------------------------------------------------

def trame2dec(trame):
    # À compléter
    pass


# --- Tests Question 2 --------------------------------------------------------
print("=" * 50)
print("QUESTION 2 — trame2dec")
print("=" * 50)
resultat = trame2dec(figure1)
print("trame2dec(figure1) =", resultat)
print("Attendu            = [78, 83, 73, 45, 66, 65, 67]")
print("Correct ?          =", resultat == [78, 83, 73, 45, 66, 65, 67])
print()


# =============================================================================
#  QUESTION 3 — Corriger la fonction dec2msg
# =============================================================================
#
#  La fonction dec2msg ci-dessous prend une liste d'entiers et doit renvoyer
#  la chaîne de caractères correspondante en consultant dict_ascii.
#
#  ELLE CONTIENT UN BUG. Identifier et corriger ce bug.
#
#  Exemples attendus :
#    dec2msg([78, 83, 73, 45, 66, 65, 67])       →  "NSI-BAC"
#    dec2msg([78, 83, 73, 200, 66, 65, 67])       →  "NSI?BAC"  (200 hors table → '?')
#
#  Indice : l'accès dict_ascii[entier] provoque une KeyError si l'entier
#  n'est pas dans le dictionnaire (valeur hors de la plage 32–126).
#  Il existe une méthode de dictionnaire qui permet d'éviter cette erreur
#  en renvoyant une valeur par défaut lorsque la clé est absente.
#
# -----------------------------------------------------------------------------

def dec2msg(liste_entiers):
    message = ""
    for entier in liste_entiers:
        message = message + dict_ascii[entier]   # ← BUG ICI : à corriger
    return message


# --- Tests Question 3 --------------------------------------------------------
print("=" * 50)
print("QUESTION 3 — dec2msg (correction du bug)")
print("=" * 50)
print(dec2msg([78, 83, 73, 45, 66, 65, 67]),   "  attendu : NSI-BAC")
print(dec2msg([78, 83, 73, 200, 66, 65, 67]),  "  attendu : NSI?BAC")
print()


# =============================================================================
#  QUESTION 4 — Corriger la fonction msg2trame
# =============================================================================
#
#  La fonction msg2trame ci-dessous prend une chaîne de caractères et doit
#  renvoyer la trame binaire correspondante (liste de tuples de 8 bits).
#
#  ELLE CONTIENT UN BUG. Identifier et corriger ce bug.
#
#  Exemple attendu :
#    msg2trame("NSI-BAC") == figure1   →  True
#
#  Indice : bin(entier)[2:] renvoie une chaîne binaire SANS les zéros de tête.
#  Par exemple : bin(78)[2:] → '1001110' (7 bits) au lieu de '01001110' (8 bits).
#  Un octet doit toujours avoir exactement 8 bits.
#  Python propose deux façons de forcer 8 caractères :
#    - bin(entier)[2:].zfill(8)
#    - f"{entier:08b}"
#
# -----------------------------------------------------------------------------

def msg2trame(message):
    trame = []
    table_inverse = {valeur: cle for cle, valeur in dict_ascii.items()}
    for caractere in message:
        entier = table_inverse.get(caractere, 63)
        bits_str = bin(entier)[2:]           # ← BUG ICI : à corriger
        octet = tuple(int(b) for b in bits_str)
        trame.append(octet)
    return trame


# --- Tests Question 4 --------------------------------------------------------
print("=" * 50)
print("QUESTION 4 — msg2trame (correction du bug)")
print("=" * 50)
resultat = msg2trame("NSI-BAC")
for i, (attendu, obtenu) in enumerate(zip(figure1, resultat)):
    ok = "OK" if attendu == obtenu else "ERREUR"
    print(f"  octet {i}: [{ok}]  attendu={attendu}  obtenu={obtenu}")
print("msg2trame('NSI-BAC') == figure1 :", resultat == figure1)
print()


# =============================================================================
#  TEST GLOBAL (pipeline complet) — décommentez une fois les 4 questions faites
# =============================================================================

# print("=" * 50)
# print("TEST GLOBAL — pipeline complet")
# print("=" * 50)
# decimaux = trame2dec(figure1)
# message  = dec2msg(decimaux)
# retour   = msg2trame(message)
# print("trame  → dec  :", decimaux)
# print("dec    → msg  :", message)
# print("msg    → trame:", retour == figure1)
