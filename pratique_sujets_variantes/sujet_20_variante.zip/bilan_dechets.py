# Coûts de collecte et traitement en euros par tonne
COUTS = {
    'ordures_menageres':   180,   # par tonne
    'verre':                55,   # par tonne
    'papier_carton':        70,   # par tonne
    'plastiques':          210,   # par tonne
    'dechets_verts':        90,   # par tonne
    'encombrants':         140,   # par tonne
}

# Exemples de quartiers pour les tests
# Les quantités sont exprimées en tonnes par mois

quartier1 = {
    'ordures_menageres': 12,
    'verre':              4,
    'papier_carton':      6,
    'plastiques':         3,
    'dechets_verts':      8,
    'encombrants':        2,
}

quartier2 = {
    'ordures_menageres': 20,
    'plastiques':         5,
    'encombrants':        1,
}

quartier3 = {
    'ordures_menageres':  8,
    'verre':              2,
    'papier_carton':      4,
    'plastiques':         2,
    'dechets_verts':     15,
    'encombrants':        1,
}

quartier4 = {
    'ordures_menageres': 10,
    'verre':              3,
}

quartier5 = {
    'ordures_menageres': 15,
    'verre':              6,
}

quartier6 = {}

#############################################################################
# Écrire le code de la fonction cout_total de la question 1                 #
#############################################################################


#############################################################################
# Écrire le code de la fonction classer_par_cout de la question 2           #
#############################################################################


#############################################################################
# Fonction fournie pour la question 3                                       #
#############################################################################

def comparer_quartiers(q1, q2):
    """Compare les coûts de collecte de deux quartiers pour chaque flux de déchets.
    Renvoie un dictionnaire associant à chaque flux la différence de coût
    (coût du quartier 2 moins coût du quartier 1).
    Si un flux est absent chez un quartier, son coût est considéré nul."""
    differences = {}
    for flux in COUTS:
        quantite1 = 0
        quantite2 = 0
        if flux in q1:
            quantite1 = q1[flux]
        if flux in q2:
            quantite2 = q2[flux]
        cout1 = quantite1 * COUTS[flux]
        cout2 = quantite2 * COUTS[flux]
        differences[flux] = cout2 - cout1
    return differences

def test_comparer_quartiers():
    diff = comparer_quartiers(quartier4, quartier5)
    assert diff['ordures_menageres'] == 900    # (15 - 10) * 180
    assert diff['verre'] == 165                # (6 - 3) * 55
    # Ajouter vos tests ci-dessous avec justifications


#############################################################################
# Fonction fournie pour la question 4                                       #
#############################################################################

def comparer_quartiers_v2(q1, q2):
    """Compare les coûts de collecte de deux quartiers pour chaque flux de déchets.
    Renvoie un dictionnaire associant à chaque flux l'écart de coût exprimé
    en pourcentage de la valeur du premier quartier."""
    ecarts = {}
    for flux in COUTS:
        quantite1 = 0
        quantite2 = 0
        if flux in q1:
            quantite1 = q1[flux]
        if flux in q2:
            quantite2 = q2[flux]
        cout1 = quantite1 * COUTS[flux]
        cout2 = quantite2 * COUTS[flux]
        ecarts[flux] = (cout2 - cout1) / cout1 * 100
    return ecarts
